60 days Udacity Challenge for Bertelsmann Tech Scholarship 2019-2020 

Day 1 (12/9/2018) : Python Revision
Data Types:
1. Numbers
2. Strings
3. Print Formatting
4. Lists
5. Dictionaries
6. Booleans
7. Tuples and Sets
8. Comparison Operators
9. If,elif and else statements

Day 2 (12/10/2019): Python Revision
1. For Loops
2. While Loops
3. Functions
4. Map
5. Lambda Expression
6. Filter
7. Methods
8. In Operator
9. Tuple Unpacking

Day 3(12/11/2019)
1.Numpy Revision
   a. Numpy Arrays
   b. Numpy Arange
   c. Numpy Zeros
   d. Numpy Ones
   e. Numpy Linspace
   f. Numpy Identity Matrix
   g. Numpy Random
2. Numpy Indexing and Selection
   a. Slicing and Dicing Arrays
   b.Viewing Slice of Arrays without copying them
   c. Copying Arrays
   d.Indexing a 2D array (Matrix)
   e. Array Comparison Operators
   